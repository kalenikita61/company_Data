﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace CompanyData
{
    class Employee
    {
        [Key]
        public int Eid { get; set; }
        [Required]
        public string Ename { get; set; }
        public string Designation { get; set; }
        public double salary { get; set; }

       
        public int Did { get; set; }
        public Department dep{ get; set; }


    }
}
//[ForeignKey("Standard")]
//public int StandardRefId { get; set; }
//public Standard Standard { get; set; }