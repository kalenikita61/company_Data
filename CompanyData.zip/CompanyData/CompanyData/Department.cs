﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CompanyData
{
    class Department
    {
        [Key]
        public int Did { get; set; }
        [Required]
        public string Dname { get; set; }
        public string Location { get; set; }

        
    }
}

//[ForeignKey("Standard")]
//public int StandardRefId { get; set; }
//public Standard Standard { get; set; }