﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanyData
{
    class Program
    {
        private static void insertDepartment()
        {
            CompanyContext context = new CompanyContext();
            Console.WriteLine("Enter Department id:");
            int Did = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Department:");
            string Dname = Console.ReadLine();

            Console.WriteLine("Enter Location:");
            string Location = Console.ReadLine();

            Department dept = new Department { Did = Did, Dname = Dname,Location=Location};
            context.Department1.Add(dept);
            context.SaveChanges();
        }
        private static void insertEmployee()
        {
            CompanyContext context = new CompanyContext();
            Console.WriteLine("Enter Employee id:");
            int Eid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee Name:");
            string Ename = Console.ReadLine();
            Console.WriteLine("Enter Designation:");
            string Designation = Console.ReadLine();

            Console.WriteLine("Enter salary:");
            Double salary = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Did:");
            int Did = Convert.ToInt32(Console.ReadLine());

            Employee emp = new Employee { Eid = Eid, Ename = Ename, Designation = Designation ,salary=salary,Did=Did};
            context.Employee1.Add(emp);
             context.SaveChanges();


        }

        static void Main(string[] args)
        {
           insertDepartment();
            
            insertEmployee();
            Console.ReadKey();

        }
    }
}
