﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace CompanyData
{
    class CompanyContext:DbContext
    {
        public CompanyContext():base("CompanyContext")
            {
            }
        public DbSet<Department> Department1 { get; set; }
        public DbSet<Employee> Employee1 { get; set; }

    }
}
